-- ============================================================
-- TABLE: erpcompanymodules
-- Active/désactive les modules par société
-- ============================================================

CREATE TABLE IF NOT EXISTS `erpcompanymodules` (
  `Id` char(36) NOT NULL,
  `CompanyId` varchar(36) NOT NULL COMMENT 'ID de la société cliente',
  `ModuleCode` varchar(64) NOT NULL COMMENT 'Code du module: auto_parts, hardware, appliances, fashion...',
  `ModuleName` varchar(128) NOT NULL COMMENT 'Nom affiché du module',
  `IsActive` tinyint(1) NOT NULL DEFAULT '1',
  `ConfigJson` json DEFAULT NULL COMMENT 'Configuration spécifique au module (API keys, sync frequency, etc.)',
  `ActivatedAt` datetime(6) NOT NULL,
  `ExpiresAt` datetime(6) DEFAULT NULL COMMENT 'Date d'expiration de la licence module',
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_CompanyModules_Company_Module` (`CompanyId`,`ModuleCode`),
  KEY `IX_CompanyModules_CompanyId` (`CompanyId`),
  KEY `IX_CompanyModules_ModuleCode` (`ModuleCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Modules activés par société';


-- ============================================================
-- DONNÉES DE DÉMO
-- ============================================================

INSERT INTO `erpcompanymodules` (`Id`, `CompanyId`, `ModuleCode`, `ModuleName`, `IsActive`, `ConfigJson`, `ActivatedAt`, `CreatedAt`) VALUES
('11111111-1111-1111-1111-111111111111', 'COMP-001', 'core', 'Core ERP', 1, NULL, NOW(), NOW()),
('22222222-2222-2222-2222-222222222222', 'COMP-001', 'auto_parts', 'Module Pièces Auto', 1, '{"api_source": "rapidapi", "sync_frequency": "daily", "default_vat": 20.0}', NOW(), NOW()),
('33333333-3333-3333-3333-333333333333', 'COMP-002', 'core', 'Core ERP', 1, NULL, NOW(), NOW()),
('44444444-4444-4444-4444-444444444444', 'COMP-002', 'hardware', 'Module Quincaillerie', 1, '{"default_attributes": ["filetage","materiau","norme_din"]}', NOW(), NOW()),
('55555555-5555-5555-5555-555555555555', 'COMP-003', 'core', 'Core ERP', 1, NULL, NOW(), NOW()),
('66666666-6666-6666-6666-666666666666', 'COMP-003', 'appliances', 'Module Électroménager', 1, '{"warranty_default_months": 24}', NOW(), NOW())
ON DUPLICATE KEY UPDATE UpdatedAt = NOW();
