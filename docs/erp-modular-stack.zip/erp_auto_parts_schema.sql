-- ============================================================
-- TABLES COMPLÉMENTAIRES POUR ERP PIÈCES AUTO
-- À ajouter à ton schéma existant
-- ============================================================

-- Table: erpproductvehicles
-- Compatibilité véhicule (ESSENTIEL pour pièces auto)
-- Permet de savoir quelle pièce va sur quel véhicule
CREATE TABLE IF NOT EXISTS `erpproductvehicles` (
  `Id` char(36) NOT NULL,
  `ProductId` int NOT NULL,
  `Make` varchar(128) NOT NULL COMMENT 'Marque véhicule (BMW, Renault, VW...)',
  `Model` varchar(128) NOT NULL COMMENT 'Modèle (Clio, Golf, 3-Series...)',
  `YearFrom` int DEFAULT NULL COMMENT 'Année début de compatibilité',
  `YearTo` int DEFAULT NULL COMMENT 'Année fin de compatibilité',
  `EngineCode` varchar(64) DEFAULT NULL COMMENT 'Code moteur (ex: N47D20)',
  `KType` varchar(64) DEFAULT NULL COMMENT 'ID TecDoc du véhicule',
  `BodyType` varchar(64) DEFAULT NULL COMMENT 'Type carrosserie (Berline, Break...)',
  `FuelType` varchar(64) DEFAULT NULL COMMENT 'Carburant (Diesel, Essence, Elec...)',
  `PowerKW` int DEFAULT NULL COMMENT 'Puissance en kW',
  `PowerHP` int DEFAULT NULL COMMENT 'Puissance en CV',
  `Ccm` int DEFAULT NULL COMMENT 'Cylindrée en cm3',
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ProductVehicles_ProductId` (`ProductId`),
  KEY `IX_ProductVehicles_Make_Model` (`Make`,`Model`),
  KEY `IX_ProductVehicles_KType` (`KType`),
  KEY `IX_ProductVehicles_YearRange` (`YearFrom`,`YearTo`),
  CONSTRAINT `FK_ProductVehicles_Products` 
    FOREIGN KEY (`ProductId`) REFERENCES `erpproducts` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Compatibilité véhicule pour chaque pièce';


-- Table: erpsuppliers
-- Fournisseurs de données / APIs
CREATE TABLE IF NOT EXISTS `erpsuppliers` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL COMMENT 'Nom du fournisseur (TecDoc, RapidAPI...)',
  `Slug` varchar(255) NOT NULL,
  `ApiEndpoint` varchar(512) DEFAULT NULL,
  `ApiKey` varchar(512) DEFAULT NULL,
  `ApiType` varchar(64) DEFAULT 'rest' COMMENT 'rest, soap, graphql, file',
  `SyncFrequency` varchar(32) DEFAULT 'daily' COMMENT 'hourly, daily, weekly, manual',
  `LastSyncAt` datetime(6) DEFAULT NULL,
  `LastSyncStatus` varchar(32) DEFAULT NULL COMMENT 'success, error, partial',
  `LastSyncMessage` varchar(1000) DEFAULT NULL,
  `IsActive` tinyint(1) NOT NULL DEFAULT '1',
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Suppliers_Name` (`Name`),
  UNIQUE KEY `IX_Suppliers_Slug` (`Slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Fournisseurs de données catalogue';


-- Table: erpsyncjobs
-- Historique des synchronisations
CREATE TABLE IF NOT EXISTS `erpsyncjobs` (
  `Id` char(36) NOT NULL,
  `SupplierId` int DEFAULT NULL,
  `JobType` varchar(64) NOT NULL COMMENT 'full, incremental, oem_search, vehicle_sync',
  `Status` varchar(32) NOT NULL DEFAULT 'running' COMMENT 'running, completed, failed',
  `StartedAt` datetime(6) NOT NULL,
  `CompletedAt` datetime(6) DEFAULT NULL,
  `ProductsCreated` int NOT NULL DEFAULT '0',
  `ProductsUpdated` int NOT NULL DEFAULT '0',
  `ImagesAdded` int NOT NULL DEFAULT '0',
  `VehiclesAdded` int NOT NULL DEFAULT '0',
  `ErrorsCount` int NOT NULL DEFAULT '0',
  `ErrorDetails` json DEFAULT NULL,
  `CreatedBy` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_SyncJobs_Status` (`Status`),
  KEY `IX_SyncJobs_StartedAt` (`StartedAt`),
  CONSTRAINT `FK_SyncJobs_Suppliers` 
    FOREIGN KEY (`SupplierId`) REFERENCES `erpsuppliers` (`Id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Journal des jobs de synchronisation';


-- Table: erpoemcrossreferences
-- Cross-références OEM (une pièce = plusieurs numéros OEM)
CREATE TABLE IF NOT EXISTS `erpoemcrossreferences` (
  `Id` char(36) NOT NULL,
  `ProductId` int NOT NULL,
  `OemNumber` varchar(128) NOT NULL COMMENT 'Numéro OEM alternatif',
  `Brand` varchar(128) DEFAULT NULL COMMENT 'Marque du fabricant OEM',
  `IsOriginal` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = numéro original du constructeur',
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_OemCross_Product_Oem` (`ProductId`,`OemNumber`),
  KEY `IX_OemCross_OemNumber` (`OemNumber`),
  CONSTRAINT `FK_OemCross_Products` 
    FOREIGN KEY (`ProductId`) REFERENCES `erpproducts` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Cross-références OEM pour recherche multi-numéros';


-- ============================================================
-- INDEXES SUPPLÉMENTAIRES SUR TABLES EXISTANTES
-- ============================================================

-- Index pour recherche rapide par référence fabricant
ALTER TABLE `erpproducts` 
  ADD KEY `IX_ErpProducts_Manufacturer` (`Manufacturer`),
  ADD KEY `IX_ErpProducts_DataSource` (`DataSource`),
  ADD KEY `IX_ErpProducts_LastSyncAt` (`LastSyncAt`),
  ADD KEY `IX_ErpProducts_TypeName` (`TypeName`);

-- Index pour recherche par nom de pièce (FULLTEXT)
ALTER TABLE `erpproducts` 
  ADD FULLTEXT INDEX `FT_ErpProducts_Name` (`Name`);


-- ============================================================
-- DONNÉES INITIALES
-- ============================================================

INSERT INTO `erpsuppliers` (`Name`, `Slug`, `ApiType`, `SyncFrequency`, `IsActive`, `CreatedAt`) VALUES
('Auto Parts Catalog (RapidAPI)', 'auto-parts-catalog', 'rest', 'daily', 1, NOW()),
('TecDoc Web Service', 'tecdoc', 'soap', 'weekly', 0, NOW()),
('Epicor Catalog', 'epicor', 'rest', 'weekly', 0, NOW()),
('Parts-Catalogs.com', 'parts-catalogs', 'rest', 'daily', 0, NOW())
ON DUPLICATE KEY UPDATE UpdatedAt = NOW();
